---
name: chain-of-responsibility-adaptado
description: >-
  Applies the adapted Chain of Responsibility pattern, language-agnostic: a
  set of handlers that share one abstraction, each with an applicability check
  (seAplica / applies) and an action (executar / handle), with NO successor
  reference and NO handler-to-handler chaining. A coordinator Service holds the
  ordered collection of handlers and a process(...) method that walks the
  collection and runs every handler whose applicability check is true. Use when
  several rules may act on the same request/object, when order matters, when
  more than one handler can apply (no early stop), or when you want to remove
  the structural coupling between handlers and change composition/order in one
  place. Do NOT use for a classic linked chain with next pointers, for a single
  strategy chosen at runtime (use Strategy), or for pub/sub.
license: MIT
metadata:
  pattern: chain-of-responsibility-adapted
---

# Adapted Chain of Responsibility (language-agnostic)

A sequence of handlers without the chain. Each handler is isolated; a
`Service` owns the collection and drives the sequence.

## Traditional vs adapted

```
Traditional
  Client --> Handler A -> Handler B -> Handler C
                successor    successor   (next pointers)

Adapted
  Client --> RuleService
                 +--> RuleA
                 +--> RuleB
                 +--> RuleC
             (no successor references; the Service coordinates)
```

## When to use

- Several independent rules may act on the same request/object.
- Order of application matters.
- More than one handler may apply to the same request (not necessarily stop at
  the first).
- You want to change composition and order without editing the handlers.
- You want each handler to depend on nothing but the shared abstraction.

## When NOT to use

- A single algorithm picked at runtime - that is Strategy.
- A classic linked chain where each handler decides to delegate to a successor.
- One-to-many fan-out with async delivery - that is pub/sub or events.

## Participants

| Participant | Responsibility |
|---|---|
| Request/context | The data the handlers read and mutate (one or more domain objects, or a context object). |
| Handler abstraction | Common type, e.g. `RegraChainOfResponsibility`; declares `seAplica(...)` and `executar(...)` (or `applies`/`handle`). |
| Concrete handler | `Regra<X>ChainOfResponsibility`: decides applicability and performs its rule. Holds no reference to any other handler. |
| Coordinator `Service` | `RuleService`/`<X>Service` with suffix `Service`: holds the collection (usually a list), and `processar(...)`/`process(...)` iterates and runs the applicable handlers. |

## Rules

1. One shared abstraction for handlers; every handler implements it.
2. Each handler exposes an **applicability** method: `seAplica(...)` / `applies(...)`.
3. Each handler exposes an **action** method: `executar(...)` / `handle(...)`,
   ideally `void`, mutating the received object(s) directly.
4. A handler receives one or more domain objects / a context, as its rule needs.
5. **No handler holds a reference to another handler** and no handler invokes the
   next one.
6. A `Service` owns the ordered collection of handlers.
7. `Service.process(...)` walks the collection **in order**, and for each handler
   whose applicability is true, calls its action.
8. Multiple handlers may run over the same request; there is no implicit stop.
9. The collection order defines execution order when order matters.

## Workflow

1. Model the request/context the rules operate on.
2. Define the handler abstraction with the applicability and action methods.
3. Implement one concrete handler per rule; keep it free of any successor or
   knowledge of other handlers.
4. Create a `Service` that receives the ordered collection and implements
   `process`.
5. Compose the collection at the configuration/composition root, in the intended
   order.
6. Validate the checklist below.

## Validation checklist

- [ ] Handlers share one abstraction and implement it.
- [ ] Every handler has an applicability check and a void action.
- [ ] No handler holds or calls another handler.
- [ ] A `Service` owns the collection and iterates it in order.
- [ ] Multiple applicable handlers all run (no early stop).
- [ ] Reordering/composing the chain happens only in the Service collection.

## Anti-patterns

- Handlers referencing each other (`setNext`, `proximo`, `successor`).
- A handler calling the next handler directly.
- Applicability logic split between the Service and the handlers.
- A `Service` that is a god object doing the rules instead of delegating.

## References

- `references/adapted-chain.md` - worked example and pseudocode.
- `references/vs-classic.md` - side-by-side with the classic GoF version.

## Templates

- `assets/Handler.java.template`
- `assets/Service.java.template`
