# Adapted chain: worked example (pseudocode)

Handlers share one abstraction; a `Service` coordinates the ordered collection.
Language-agnostic pseudocode first, then notes.

## Request/context

```
type DiscountRequest:
  customer: Customer
  order: Order
  appliedRules: list of text
```

## Handler abstraction

```
abstract type DiscountRuleChainOfResponsibility (or an interface):
  function applies(request) -> boolean      // seAplica(...)
  function handle(request)  -> void         // executar(...) ; mutates request
```

## Concrete handlers (no successor references)

```
type BlackFridayRule extends DiscountRuleChainOfResponsibility:
  function applies(request): return request.order.date == BLACK_FRIDAY
  function handle(request):  request.order.total = request.order.total * 0.9
                             request.appliedRules.add("black-friday")

type LoyaltyRule extends DiscountRuleChainOfResponsibility:
  function applies(request): return request.customer.loyalty >= 12
  function handle(request):  request.order.total = request.order.total - 5
                             request.appliedRules.add("loyalty")
```

Neither rule knows the other exists.

## Coordinator Service (owns the collection + order)

```
type DiscountService:
  rules: list of DiscountRuleChainOfResponsibility   // ordered at composition

  function process(request) -> void:
    for rule in rules:
      if rule.applies(request):
        rule.handle(request)      // several rules may apply; no early stop
```

## Composition (configuration root)

```
service = new DiscountService([
  new BlackFridayRule(),
  new LoyaltyRule()
])
service.process(request)
```

## Notes

- The action is `void` and mutates the received domain object(s).
- A handler may receive one or more domain objects or a context, as its rule
  needs.
- Order is defined only by the collection; changing order is a composition
  change, not a handler change.
- If a rule must stop the rest, model that as an explicit flag on the request
  read by the applicability checks (do not reintroduce next pointers).
