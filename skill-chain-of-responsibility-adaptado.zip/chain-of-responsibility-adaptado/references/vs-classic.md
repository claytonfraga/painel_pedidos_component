# Adapted vs classic Chain of Responsibility

## Structure

Classic (GoF):

```
Client -> Handler
Handler { Handler successor; handle() { if canHandle() ... else successor.handle() } }
```

Adapted:

```
Client -> Service
Service { List<Rule> rules; process() { for r in rules { if r.applies() r.handle() } } }
Rule { applies(); handle(); }   // no successor
```

## Differences

| Aspect | Classic GoF | Adapted |
|---|---|---|
| Link | Each handler holds `next`/`successor` | No link; the Service holds the list |
| Continuation | Handler decides to delegate to the next | The Service iterates the collection |
| Stop | Usually stops at the first handler that handles | Runs every applicable handler |
| Coupling | Handler-to-handler | Handlers decoupled; only the Service knows the set |
| Order | Implicit in the links | Explicit in the collection order |
| Composition change | Rewire links | Edit the collection in the Service |

## Why the adaptation helps

- Each rule is isolated: single responsibility, open/closed (add a rule = add a
  class + a line in the composition).
- Dependencies point only to the shared abstraction; the Service depends on the
  abstraction, not on concrete rules.
- Composition and order are a single, visible place.

## Choosing

- Use the adapted form when the request flows through independent rules and more
  than one may apply.
- Use the classic form when each handler is a station that may pass the request
  on exactly once and earlier handlers are genuinely unaware of the rest.
