# Worked example: login (Passive View)

A login screen with Model `Usuario`, service `AutenticacaoService`, passive View
`LoginView` implementing `ILoginView`, `LoginPresenter`, and the composition
root `AplicacaoPrincipal`. Listeners are anonymous classes (no lambda).

## Model

```java
package ufes.br.loginmvp.model;

import java.util.Objects;

public class Usuario {

    private final String nome;
    private final String senha;

    public Usuario(String nome, String senha) {
        this.nome = Objects.requireNonNull(nome, "O nome nao pode ser nulo.");
        this.senha = Objects.requireNonNull(senha, "A senha nao pode ser nula.");
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }
}
```

## View abstraction

```java
package ufes.br.loginmvp.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public interface ILoginView {

    JFrame getJanelaPrincipal();

    JTextField getTxtNomeUsuario();

    JPasswordField getTxtSenha();

    JButton getBtnLogin();

    JButton getBtnLimpar();
}
```

## View (passive, prefix naming)

```java
package ufes.br.loginmvp.view;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginView extends JFrame implements ILoginView {

    private JTextField txtNomeUsuario;
    private JPasswordField txtSenha;
    private JButton btnLogin;
    private JButton btnLimpar;
    private JLabel lblNomeUsuario;
    private JLabel lblSenha;

    public LoginView() {
        initComponents();
    }

    private void initComponents() {
        lblNomeUsuario = new JLabel("Nome do usuario:");
        lblSenha = new JLabel("Senha:");
        txtNomeUsuario = new JTextField(20);
        txtSenha = new JPasswordField(20);
        btnLogin = new JButton("Acessar");
        btnLimpar = new JButton("Limpar");

        JPanel pnlPrincipal = new JPanel(new java.awt.GridLayout(3, 2));
        pnlPrincipal.add(lblNomeUsuario);
        pnlPrincipal.add(txtNomeUsuario);
        pnlPrincipal.add(lblSenha);
        pnlPrincipal.add(txtSenha);
        pnlPrincipal.add(btnLogin);
        pnlPrincipal.add(btnLimpar);

        setTitle("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(pnlPrincipal);
        pack();
        setLocationRelativeTo(null);
        setVisible(false);
    }

    @Override
    public JFrame getJanelaPrincipal() {
        return this;
    }

    @Override
    public JTextField getTxtNomeUsuario() {
        return txtNomeUsuario;
    }

    @Override
    public JPasswordField getTxtSenha() {
        return txtSenha;
    }

    @Override
    public JButton getBtnLogin() {
        return btnLogin;
    }

    @Override
    public JButton getBtnLimpar() {
        return btnLimpar;
    }
}
```

## Service

```java
package ufes.br.loginmvp.services;

import ufes.br.loginmvp.model.Usuario;

public class AutenticacaoService {

    public boolean autenticar(Usuario usuario) {
        return "usuario".equals(usuario.getNome()) && "senha".equals(usuario.getSenha());
    }
}
```

## Presenter (listeners as anonymous classes)

```java
package ufes.br.loginmvp.presenter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;
import javax.swing.JOptionPane;
import ufes.br.loginmvp.model.Usuario;
import ufes.br.loginmvp.services.AutenticacaoService;
import ufes.br.loginmvp.view.ILoginView;

public class LoginPresenter {

    private final ILoginView loginView;
    private final AutenticacaoService autenticacaoService;

    public LoginPresenter(ILoginView loginView, AutenticacaoService autenticacaoService) {
        this.loginView = Objects.requireNonNull(loginView, "A view nao pode ser nula.");
        this.autenticacaoService = Objects.requireNonNull(autenticacaoService, "O servico nao pode ser nulo.");
        configurarListeners();
        exibirTelaInicial();
    }

    private void configurarListeners() {
        loginView.getBtnLogin().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evento) {
                processarTentativaDeLogin();
            }
        });
        loginView.getBtnLimpar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evento) {
                limparCampos();
            }
        });
    }

    private void exibirTelaInicial() {
        loginView.getJanelaPrincipal().setVisible(true);
    }

    private void limparCampos() {
        loginView.getTxtNomeUsuario().setText("");
        loginView.getTxtSenha().setText("");
        loginView.getTxtNomeUsuario().requestFocusInWindow();
    }

    private void processarTentativaDeLogin() {
        String nome = loginView.getTxtNomeUsuario().getText();
        String senha = new String(loginView.getTxtSenha().getPassword());

        Usuario usuario = new Usuario(nome, senha);

        if (autenticacaoService.autenticar(usuario)) {
            JOptionPane.showMessageDialog(loginView.getJanelaPrincipal(),
                    "A tela principal seria aberta.", "Informacao", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(loginView.getJanelaPrincipal(),
                "Usuario ou senha invalidos.", "Erro", JOptionPane.ERROR_MESSAGE);
        loginView.getTxtSenha().setText("");
        loginView.getTxtSenha().requestFocusInWindow();
    }
}
```

## Composition root

```java
package ufes.br.loginmvp;

import javax.swing.UIManager;
import ufes.br.loginmvp.presenter.LoginPresenter;
import ufes.br.loginmvp.services.AutenticacaoService;
import ufes.br.loginmvp.view.ILoginView;
import ufes.br.loginmvp.view.LoginView;

public class AplicacaoPrincipal {

    public static void main(String[] args) {
        configurarLookAndFeel();
        ILoginView loginView = new LoginView();
        AutenticacaoService autenticacaoService = new AutenticacaoService();
        new LoginPresenter(loginView, autenticacaoService);
    }

    private static void configurarLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException excecao) {
            throw new IllegalStateException("Nao foi possivel configurar o Look and Feel", excecao);
        }
    }
}
```
