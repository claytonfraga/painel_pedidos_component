# Swing element naming prefixes

Adopt these prefixes according to the element type, ALWAYS, for fields and local
variables, in the View and in the Presenter.

| Component | Prefix | Example |
|---|---|---|
| `JButton` | `btn` | `btnSalvar` |
| `JCheckBox` | `chk` | `chkAtivo` |
| `JComboBox` | `cmb` | `cmbCategoria` |
| `JDatePicker` | `dtp` | `dtpDataNascimento` |
| `JDesktopPane` | `dsk` | `dskPrincipal` |
| `JFormattedTextField` | `txtFmt` | `txtFmtCpf` |
| `JLabel` | `lbl` | `lblNome` |
| `JMenu` | `mnu` | `mnuCadastro` |
| `JMenuBar` | `mnb` | `mnbPrincipal` |
| `JMenuItem` | `mit` | `mitSair` |
| `JOptionPane` | `opt` | `optConfirmacao` |
| `JPanel` | `pnl` | `pnlDados` |
| `JPopupMenu` | `pmn` | `pmnOpcoes` |
| `JProgressBar` | `prg` | `prgProgresso` |
| `JRadioButton` | `rad` | `radAdministrador` |
| `JScrollPane` | `scr` | `scrProdutos` |
| `JSplitPane` | `spt` | `sptPrincipal` |
| `JTabbedPane` | `tab` | `tabCadastro` |
| `JTable` | `tbl` | `tblProdutos` |
| `JTextField` | `txt` | `txtNome` |
| `JToggleButton` | `tgl` | `tglAtivo` |
| `JPasswordField` | `txt` | `txtSenha` |

## Getters

Getters name the element: `get` + capitalized prefixed field.
Examples: `getBtnSalvar()`, `getTxtSenha()`, `getCmbCategoria()`,
`getTblProdutos()`, `getPnlDados()`.

## Wrapper panels

For non-visual wrapper panels (e.g., a card or a container), still use the
`pnl` prefix (`pnlCartao`, `pnlConjunto`).
