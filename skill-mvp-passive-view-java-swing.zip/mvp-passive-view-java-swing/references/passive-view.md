# The MVP Passive View pattern

MVP organizes the presentation layer into View, Presenter and Model. In the
**Passive View** variant the View is deliberately passive: it captures input,
raises events and projects output, while the Presenter owns all presentation
logic and the flow.

## Participants

- **Model**: data/state and domain rules. Conceptually independent from the UI
  technology. Must not depend on Swing, logging or persistence.
- **View**: builds the visual structure and captures interactions. It forwards
  events to the Presenter and exposes only the components the Presenter needs.
  It does not talk to the Model and does not decide flow.
- **Presenter**: the coordinating unit. Receives View signals, reads/updates the
  Model and services, interprets results and instructs the View on how to
  update.
- **Service (optional)**: isolates an application/domain operation outside the
  Presenter.

## End-to-end flow

1. The composition root creates the View, the services and the Presenter
   (`new Presenter(new View(), new Service())`).
2. The Presenter configures the listeners on the View.
3. The user interacts with the View.
4. The View detects the interaction and the configured listener notifies the
   Presenter.
5. The Presenter reads the View, builds/updates the Model, calls the
   service/repository.
6. The Presenter interprets the result.
7. The Presenter instructs the View how to update the presentation.
8. The View updates itself.

## Difference from MVC

In MVC the View observes the Model and the Controller mutates it. In MVP the
Presenter explicitly mediates everything; the View never observes the Model.
This favors separation of responsibilities and testability of the presentation
layer.

## Handling messages (JOptionPane)

- Keeping `JOptionPane` in the Presenter is coherent with the passive View: the
  Presenter decides what to show.
- For better testability, abstract the output behind `ExibidorMensagem`
  (with a concrete `ExibidorMensagemJOptionPane`), so the Presenter no longer
  depends on the concrete Swing dialog.

## Testability note

The Presenter depends on `I<Nome>View`, so a test View (that records calls)
can replace the real Swing View. Prefer small interfaces with only the getters
and operations the Presenter uses.
