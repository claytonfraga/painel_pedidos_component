# Presenter rules (Passive View)

## Responsibilities

- Receive the `I<Nome>View` and the Model/services by constructor.
- Configure the listeners on the View.
- Read data from the View, create/update the Model, call services.
- Decide the response and instruct the View how to update.
- Own the flow; the View never decides flow.

## Dependencies

```java
public Presenter(IProdutoView view, ProdutoService produtoService) {
    this.view = Objects.requireNonNull(view, "view");
    this.produtoService = Objects.requireNonNull(produtoService, "produtoService");
    configurarListeners();
    exibirTelaInicial();
}
```

- Depend on the abstraction `I<Nome>View`, never on the concrete View.
- Do NOT instantiate the concrete View inside the Presenter; the composition
  root does it.

## Listeners

Configure listeners in the Presenter, as **anonymous classes** at the point of
use. Never create named listener classes.

```java
private void configurarListeners() {
    view.getBtnSalvar().addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent evento) {
            salvar();
        }
    });
}
```

- Projects that forbid lambda: use the anonymous class above.
- Projects that allow lambda: `evento -> salvar()` is acceptable, but still no
  named listener class.
- For Swing `AbstractButton`, to reset listeners when switching modes, iterate
  `getActionListeners()` and call `removeActionListener(...)`.

## Exception handling

- Throw/expect only unchecked exceptions (`RuntimeException`,
  `IllegalArgumentException`).
- Surface errors via `JOptionPane` (coherent with the passive View) or via an
  `ExibidorMensagem` abstraction for testability.

```java
try {
    salvar();
} catch (RuntimeException excecao) {
    JOptionPane.showMessageDialog(view.getJanelaPrincipal(), excecao.getMessage(),
            "Erro", JOptionPane.WARNING_MESSAGE);
}
```

## Window operations

Use a single accessor, `view.getJanelaPrincipal()`, for `setVisible`,
`setLocationRelativeTo`, `dispose`, `repaint` and as the dialog parent.

## Constraints

- No `enum`, no `instanceof`, no static attributes, no lambda (when forbidden),
  no Stream API.
- Use `Objects.requireNonNull` for nullity.
- Interface prefixed with `I`; class names singular.
