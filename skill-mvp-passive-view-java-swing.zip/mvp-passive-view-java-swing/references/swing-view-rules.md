# View rules (Passive View, NetBeans style)

## Responsibilities

The View ONLY creates and configures its visual elements. It must NOT:

- configure listeners (the Presenter does it);
- have a `main` method;
- contain flow decisions, validation, or access to the Model/services;
- expose public setters.

## Getters

Expose getters only for the elements the respective Presenter manipulates.
Example: `getBtnSalvar()`, `getTxtNome()`, `getCmbCategoria()`,
`getTblProdutos()`, `getJanelaPrincipal()`.

Return types should be the concrete Swing types (`JButton`, `JTextField`, ...)
so the Presenter can call `addActionListener`, `getText`, `setText`, etc.

## NetBeans generated-code pattern

- Constructor calls only `initComponents()`.
- `initComponents()` lives inside:
  `// <editor-fold ... GEN-BEGIN:initComponents` ... `//GEN-END:initComponents`.
- Component fields live inside:
  `// Variables declaration - do not modify` +
  `//GEN-BEGIN:variables` ... `//GEN-END:variables`.
- Keep a sibling `.form` file in sync with the field names.
- Component properties (text, colors, borders, sizes, layout) are set inside
  `initComponents()` as NetBeans does.

```java
public class ProdutoView extends javax.swing.JFrame implements IProdutoView {

    public ProdutoView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlDados = new javax.swing.JPanel();
        lblNome = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        btnSalvar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Produto");
        getContentPane().setLayout(new java.awt.BorderLayout());

        lblNome.setText("Nome:");
        pnlDados.add(lblNome);

        txtNome.setColumns(20);
        pnlDados.add(txtNome);

        btnSalvar.setText("Salvar");
        pnlDados.add(btnSalvar);

        getContentPane().add(pnlDados, java.awt.BorderLayout.CENTER);

        pack();
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public javax.swing.JFrame getJanelaPrincipal() {
        return this;
    }

    @Override
    public javax.swing.JButton getBtnSalvar() {
        return btnSalvar;
    }

    @Override
    public javax.swing.JTextField getTxtNome() {
        return txtNome;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel lblNome;
    private javax.swing.JTextField txtNome;
    private javax.swing.JPanel pnlDados;
    // End of variables declaration//GEN-END:variables
}
```

## Notes

- Maximize by default with `setExtendedState(MAXIMIZED_BOTH)` after `pack()`.
- Never `printStackTrace`; let the Presenter surface errors.
- If a configuration helper is needed, keep it private and without listeners;
  prefer inlining properties into `initComponents()`.
