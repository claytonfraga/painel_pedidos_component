---
name: mvp-passive-view-java-swing
description: >-
  Implements the Model-View-Presenter (Passive View) architecture in Java Swing,
  domain-agnostic. Use when building or refactoring desktop screens with
  Swing, separating UI from presentation logic, wiring Presenter listeners,
  exposing a passive View through an interface, composing dependencies in an
  entry point, or when the user mentions MVP, Passive View, Presenter, IView,
  Swing screen, look and feel, or Swing component naming. The View only creates
  and configures its elements (no listeners, no main, getters only for the
  elements the Presenter manipulates, no public setters) and follows the
  NetBeans generated-code pattern; the Presenter depends on the IView
  abstraction, configures listeners as anonymous classes, and coordinates the
  Model/services. Includes the Swing element prefix table (btn, cmb, lbl, pnl,
  scr, txt, ...). Covers constraints: no lambda/Stream, no enum, no instanceof,
  no static attributes, unchecked exceptions, Objects.requireNonNull, singular
  class names, interfaces prefixed with I. Do NOT use for MVC web frameworks,
  JavaFX, or backend service design.
license: MIT
metadata:
  pattern: mvp-passive-view
  language: java
  ui: swing
---

# MVP Passive View in Java Swing (domain-agnostic)

Separate a Swing screen into a passive View, a coordinating Presenter, and a
Model. The Presenter owns the flow and the listeners; the View only projects
output and exposes input components.

## When to use

- Desktop screens with Swing that need testable presentation logic.
- Replacing logic scattered across JFrame/JPanel event code.
- Multiple screens sharing a consistent structure.
- Any lifecycle/status or validation flow driven by the UI.

## When NOT to use

- Web MVC (Spring MVC, JSF) or JavaFX with its own bindings.
- Pure CLI or backend-only services.

## Participants

| Participant | Responsibility |
|---|---|
| Model | Domain data and rules. No Swing, logging or persistence dependency. |
| View (`I<Nome>View` + concrete) | Builds components; exposes getters; passive. No listeners, no flow decisions. |
| Presenter | Reads the View, calls Model/services, decides and instructs the View. Owns listeners. |
| Service (optional) | Isolates an application/domain operation called by the Presenter. |
| Composition root (`Aplicacao...`) | Creates View, services and Presenter; starts the UI. |

## Non-negotiable rules

1. The Presenter depends on the View **abstraction** `I<Nome>View`; it never
   instantiates the concrete View. The composition root injects the concrete
   View.
2. The View only creates/configures its elements. It has **no listeners**, **no
   `main`**, and exposes getters **only** for elements the Presenter
   manipulates. It has **no public setters** (a setter only if internal and
   strictly necessary).
3. The View follows the NetBeans generated-code pattern: `initComponents()`
   inside `//GEN-BEGIN:initComponents` / `//GEN-END:initComponents`, fields in
   `//GEN-BEGIN:variables` / `//GEN-END:variables`, and a `.form` kept in sync.
4. The Presenter configures listeners as **anonymous classes** at the point of
   use (never named listener classes; no lambda in projects that forbid it).
5. `JOptionPane` may stay in the Presenter (keeps the View passive); for
   testability, move it behind an `ExibidorMensagem` abstraction.
6. Only unchecked exceptions (`RuntimeException`, `IllegalArgumentException`)
   and `Objects.requireNonNull` for nullity.
7. No `enum`, no `instanceof`, no static attributes (no constants, no
   singletons), no lambda, no Stream API.
8. Class names singular; interfaces start with `I`.
9. Use the system Look and Feel:
   `UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName())`.

## Workflow

1. Define the View interface `I<Nome>View` with the getters the Presenter needs
   (plus `getJanelaPrincipal()` for window/dialog operations).
2. Implement the concrete View (NetBeans pattern) using the element prefixes.
3. Implement the Presenter: constructor receives `I<Nome>View` and
   Model/services; call `configurarListeners()`, update the View, then show it.
4. Write the composition root that creates the concrete View, services and the
   Presenter.
5. Validate the checklist.

## Validation checklist

- [ ] Presenter depends on `I<Nome>View`, not the concrete View.
- [ ] View has no listeners, no `main`, no public setters.
- [ ] View getters exist only for elements the Presenter uses.
- [ ] All listeners are in the Presenter.
- [ ] Element names follow the prefix table.
- [ ] No enum/instanceof/static/lambda/Stream; unchecked exceptions only.
- [ ] Interface prefixed with `I`; class names singular.

## References

- `references/passive-view.md` - the pattern and the end-to-end flow.
- `references/swing-view-rules.md` - View rules + NetBeans pattern.
- `references/swing-element-prefixes.md` - the component prefix table.
- `references/presenter-rules.md` - Presenter responsibilities and listeners.
- `references/example-login.md` - a complete worked example.

## Templates

- `assets/IView.java.template`
- `assets/View.java.template` (NetBeans style)
- `assets/Presenter.java.template`
- `assets/Aplicacao.java.template`
