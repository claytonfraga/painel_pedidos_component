# Variant: State on a domain context

Use this when the lifecycle belongs to a domain object (entity/model). The
context is the model itself.

## Structure

```
state/
  PedidoState.java                  (abstract)
  PedidoNovoState.java
  PedidoEmPreparoState.java
  PedidoProntoParaEntregaState.java
  PedidoEmRotaDeEntregaState.java
  PedidoEntregueState.java
  PedidoCanceladoState.java
model/
  Pedido.java                       (context)
```

## Abstract state

```java
package br.projeto.exemplo.state;

import br.projeto.exemplo.model.Pedido;
import java.util.Objects;

public abstract class PedidoState {

    protected final Pedido pedido;

    public PedidoState(Pedido pedido) {
        this.pedido = Objects.requireNonNull(pedido, "pedido");
    }

    public abstract String getNome();

    public void registrarPagamento(String formaPagamento) {
        throw new RuntimeException("Nao e possivel registrar pagamento de um pedido " + getNome());
    }

    public void marcarProntoParaEntrega() {
        throw new RuntimeException("Nao e possivel marcar como pronto para entrega um pedido " + getNome());
    }

    public void cancelar() {
        throw new RuntimeException("Nao e possivel cancelar um pedido " + getNome());
    }
}
```

## Concrete states (rules + constructor validation)

```java
package br.projeto.exemplo.state;

import br.projeto.exemplo.model.Pedido;

public class PedidoNovoState extends PedidoState {

    public PedidoNovoState(Pedido pedido) {
        super(pedido);
    }

    @Override
    public String getNome() {
        return "Novo";
    }

    @Override
    public void registrarPagamento(String formaPagamento) {
        pedido.aplicarPagamento(formaPagamento);
        pedido.setEstado(new PedidoEmPreparoState(pedido));
    }

    @Override
    public void cancelar() {
        pedido.setEstado(new PedidoCanceladoState(pedido));
    }
}
```

```java
package br.projeto.exemplo.state;

import br.projeto.exemplo.model.Pedido;

public class PedidoEmPreparoState extends PedidoState {

    public PedidoEmPreparoState(Pedido pedido) {
        super(pedido);
        if (!pedido.isPagamentoRegistrado()) {
            throw new RuntimeException("Nao e possivel entrar em preparo sem pagamento registrado");
        }
    }

    @Override
    public String getNome() {
        return "Em preparo";
    }

    @Override
    public void marcarProntoParaEntrega() {
        pedido.setEstado(new PedidoProntoParaEntregaState(pedido));
    }

    @Override
    public void cancelar() {
        pedido.setEstado(new PedidoCanceladoState(pedido));
    }
}
```

```java
package br.projeto.exemplo.state;

import br.projeto.exemplo.model.Pedido;

public class PedidoCanceladoState extends PedidoState {

    public PedidoCanceladoState(Pedido pedido) {
        super(pedido);
        pedido.confirmarCancelamento();
    }

    @Override
    public String getNome() {
        return "Cancelado";
    }
}
```

## Context (the model)

```java
package br.projeto.exemplo.model;

import br.projeto.exemplo.state.PedidoNovoState;
import br.projeto.exemplo.state.PedidoState;
import java.util.Objects;

public class Pedido {

    private double valorTotal;
    private double creditoGerado;
    private String formaPagamento;
    private boolean pagamentoRegistrado;
    private PedidoState estado;

    public Pedido(double valorTotal) {
        this.valorTotal = valorTotal;
        this.creditoGerado = 0.0;
        this.estado = new PedidoNovoState(this);
    }

    public void registrarPagamento(String formaPagamento) {
        estado.registrarPagamento(formaPagamento);
    }

    public void marcarProntoParaEntrega() {
        estado.marcarProntoParaEntrega();
    }

    public void cancelar() {
        estado.cancelar();
    }

    void aplicarPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
        this.pagamentoRegistrado = true;
    }

    void confirmarCancelamento() {
        this.creditoGerado = pagamentoRegistrado ? valorTotal : 0.0;
    }

    public boolean isPagamentoRegistrado() {
        return pagamentoRegistrado;
    }

    public PedidoState getEstado() {
        return estado;
    }

    public void setEstado(PedidoState estado) {
        this.estado = Objects.requireNonNull(estado, "estado");
    }
}
```

## Notes

- The repository/persistence layer never knows status strings; it seeds data by
  calling context operations (`registrarPagamento`, `cancelar`, ...), so the
  domain rules are exercised.
- Add a new status by adding a class only (OCP).
- Keep helper mutators (`aplicarPagamento`, `confirmarCancelamento`) minimal and
  package-private when the state lives in the same module; make them public only
  when the `state` package is separate.
