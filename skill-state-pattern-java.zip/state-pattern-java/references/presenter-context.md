# Variant: State on a Presenter/UI context

Use this when a screen has modes (inclusion, visualization, edition) with
different enabled components, actions and listeners. The context is the
Presenter; the states are presenter states.

## Why

- Keeps the Presenter free of `ActionListener` registration.
- Guarantees the previous state's listeners are removed before installing the
  new ones (avoids the Swing bug where one click runs the action N times).
- Centralizes exception handling for UI actions in the abstraction.

## Abstract presenter state

```java
package br.projeto.exemplo.presenter;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.JOptionPane;

public abstract class ProdutoPresenterState {

    private final ProdutoPresenter presenter;

    public ProdutoPresenterState(ProdutoPresenter presenter) {
        this.presenter = presenter;
    }

    // Single entry point: clear old listeners, configure the new state.
    public final void ativar() {
        limparListeners();
        configurarComponentes();
        configurarListeners();
    }

    protected abstract void configurarComponentes();

    protected void configurarListeners() {
    }

    protected final void adicionarListenerSalvar() {
        getView().getBtnSalvar().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evento) {
                executarAcao();
            }
        });
    }

    protected final void limparListeners() {
        limparListeners(getView().getBtnSalvar());
        limparListeners(getView().getBtnFechar());
    }

    private void limparListeners(AbstractButton botao) {
        ActionListener[] listeners = botao.getActionListeners();
        for (ActionListener listener : listeners) {
            botao.removeActionListener(listener);
        }
    }

    private void executarAcao() {
        try {
            salvar();
        } catch (RuntimeException excecao) {
            JOptionPane.showMessageDialog(
                    getView(),
                    excecao.getMessage(),
                    "Erro",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    protected final ProdutoPresenter getPresenter() {
        return presenter;
    }

    protected final ProdutoView getView() {
        return presenter.getView();
    }

    public void salvar() {
        throw new IllegalStateException("Nao e possivel salvar neste estado");
    }

    public void editar() {
        throw new IllegalStateException("Nao e possivel editar neste estado");
    }

    public void fechar() {
        throw new IllegalStateException("Nao e possivel fechar neste estado");
    }

    public void cancelar() {
        throw new IllegalStateException("Nao e possivel cancelar neste estado");
    }
}
```

> If the project allows lambdas, `evento -> executarAcao()` may replace the
> anonymous `ActionListener`. In projects that forbid lambda, keep the anonymous
> class. Never create a named listener class.

## Concrete state

```java
package br.projeto.exemplo.presenter;

public class InclusaoState extends ProdutoPresenterState {

    public InclusaoState(ProdutoPresenter presenter) {
        super(presenter);
    }

    @Override
    protected void configurarComponentes() {
        getView().getTxtNomeProduto().setEnabled(true);
        getView().getBtnSalvar().setEnabled(true);
    }

    @Override
    protected void configurarListeners() {
        adicionarListenerSalvar();
    }

    @Override
    public void salvar() {
        String nome = getView().getTxtNomeProduto().getText();
        if (nome == null || nome.trim().isEmpty()) {
            throw new RuntimeException("O nome e obrigatorio.");
        }
        // ... persist via presenter-callable service ...
        getPresenter().alterarEstado(new VisualizacaoState(getPresenter()));
    }

    @Override
    public void fechar() {
        getView().dispose();
    }
}
```

## Context (Presenter)

```java
public void alterarEstado(ProdutoPresenterState novoEstado) {
    this.estado = java.util.Objects.requireNonNull(novoEstado, "novoEstado");
    this.estado.ativar();
}

public void salvar() {
    estado.salvar();
}
```

## Required order (critical)

1. Create the concrete `View` BEFORE creating the initial state (states call
   `presenter.getView()`).
2. Construct the initial state and call `alterarEstado(...)`, which sets the
   field and calls `ativar()`.
3. Do NOT modify the UI in the state constructor; do it in
   `configurarComponentes()` (invoked by `ativar()`).
