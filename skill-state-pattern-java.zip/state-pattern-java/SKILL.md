---
name: state-pattern-java
description: >-
  Applies the GoF State pattern in Java in a domain-agnostic way. Use when
  modeling lifecycles/statuses (orders, doors, documents, subscriptions,
  tickets, screens/presenters) with a closed-but-evolving set of states, when
  replacing enum/switch status logic, or when adding or refactoring State. The
  style is: a context holds a state; an abstract state owns default operations
  that throw; each concrete state is named <Contexto><Situacao>State, validates
  its preconditions in the constructor, owns the rules of that state, and
  transitions via contexto.setEstado(new ProximoState(contexto)). Covers
  SOLID (SRP/OCP/LSP/DIP) and constraints (no enum, no instanceof, no static
  attributes, no lambda/Stream, unchecked exceptions). Do NOT use for simple
  two-value boolean flags, for plain enum mapping, or for DI/factory concerns.
license: MIT
metadata:
  pattern: gof-state
  language: java
---

# GoF State in Java (domain-agnostic)

Model a lifecycle as a set of collaborating state objects instead of a status
field with branching. This skill encodes a specific, opinionated style.

## When to use

- An object has a lifecycle with distinct statuses and rules per status
  (order, door, document, subscription, ticket, machine).
- Transitions are conditional and must be validated.
- New statuses are expected over time (open for extension).
- A UI/Presenter has modes (inclusion/view/edition) with different enabled
  components, actions, and listeners.

## When NOT to use

- Two trivial boolean values with no real rules.
- Just mapping a value to a label (that is a lookup, not State).
- Cross-cutting creation/wiring concerns (use a factory/composition root).

## Non-negotiable rules

Apply these while implementing State:

1. Abstract state class named `<Contexto>State` (e.g., `PedidoState`), in a
   dedicated `state` package, holding the context reference:
   `protected final <Contexto> contexto;` with constructor
   `<Contexto>State(<Contexto> contexto)`.
2. Default operations live in the abstract state and **throw an unchecked
   exception** with a deterministic message. Concrete states override only the
   operations allowed in that state.
3. Concrete states are named `<Contexto><Situacao>State` (e.g.,
   `PedidoNovoState`, `PedidoCanceladoState`). Names are singular.
4. Transitions always go through the context:
   `contexto.setEstado(new <Proximo><Situacao>State(contexto))`.
5. **Logic in the constructor.** Each concrete state validates its preconditions
   in its own constructor. If not satisfied, throw; the transition must NOT
   happen (the context state stays unchanged). States also compute side effects
   at construction when applicable (e.g., compute a credit, snapshot a value).
6. The state owns the rules of what can happen in that status; it is not a mere
   name tag.
7. The context: holds `estado`, initializes `estado = new <Primeiro>State(this)`,
   delegates every operation to `estado`, and exposes `getEstado()` /
   `setEstado(<Contexto>State estado)`.
8. Constraints (project style): no `enum`, no `instanceof`, no static
   attributes (no constants, no singletons — instantiate states per use), no
   lambda, no Stream API. Use `Objects.requireNonNull` for null checks and
   unchecked exceptions only.
9. Interfaces start with `I` (e.g., `IRepository`). Model/data classes keep the
   domain concept only, without pattern/architectural suffixes.
10. Keep the context API stable: the rest of the system must not learn about the
    concrete states; it only calls context operations.

## Participants and responsibilities

| Participant | Responsibility |
|---|---|
| Context | Holds the current state; delegates operations; owns its own data. |
| Abstract state `<Contexto>State` | Declares operations; defaults throw; shares helpers. |
| Concrete state `<Contexto><Situacao>State` | Validates preconditions, applies side effects, performs allowed transitions. |

## Transition mechanics

```
Contexto.operacaoX()  ->  estado.operacaoX()
                            -> (allowed) valida no construtor do proximo estado
                            -> contexto.setEstado(new ProximoState(contexto))
```

Because the next state is constructed before being set, precondition checks in
its constructor naturally abort invalid transitions.

## SOLID mapping (why this style)

- **SRP**: status names and rules live in state classes; persistence only
  persists; the context only orchestrates.
- **OCP**: adding a status = adding a class, without editing the others.
- **LSP**: every concrete state is substitutable for the abstract state.
- **DIP**: the context depends on the abstraction `<Contexto>State`, not on
  concrete states or on status strings.

## Anti-patterns to avoid

- `enum Status` plus `switch`/`if` chains, or `instanceof` checks.
- Static singletons for states.
- Status strings duplicated across services/repositories.
- Putting transition rules in the context or in the repository.
- Mutating the context before validating the target state (validate first).
- In UI/presenter states: forgetting to remove the previous state's listeners
  (a click would run the action several times).

## Workflow

1. Identify the context class and its operations.
2. List the states (nouns, singular) and the allowed operations per state.
3. Create the abstract `<Contexto>State` with defaults that throw.
4. Create one concrete `<Contexto><Situacao>State` per status:
   - constructor: `super(contexto)` + precondition validation + side effects.
   - override only the allowed operations and transition.
5. In the context: field, `estado = new <Primeiro>State(this)`, delegation
   methods, `getEstado()`/`setEstado(...)`.
6. Replace call sites (if any) that used status strings/enums with context
   operations.
7. Validate the checklist below.

## Validation checklist

- [ ] Abstract state holds the context and has a single creation point.
- [ ] Every default operation throws an unchecked exception with a clear message.
- [ ] Each concrete state validates preconditions in its constructor.
- [ ] A failing precondition does not change the context state.
- [ ] No `enum`, `instanceof`, static attribute, lambda, or Stream.
- [ ] No status string duplicated outside the state classes.
- [ ] New status would require only a new class (OCP).
- [ ] The rest of the system uses only the context API.

## Variants

- **Domain context** (model/entity lifecycle): see
  `references/domain-context.md`.
- **Presenter/UI context** (screen modes with enabled components, actions and
  listeners): see `references/presenter-context.md`.

## Templates

- `assets/EstadoAbstrato.java.template`
- `assets/EstadoConcreto.java.template`
- `assets/Contexto.java.template`

## Authoring note

Each Java file may carry the author comment in the NetBeans style before the
type declaration:

```java
/**
 *
 * @author <autor>
 */
```
