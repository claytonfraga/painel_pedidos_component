---
name: netbeans-swing-view
description: >-
  Creates NetBeans-compatible Java Swing Views (JFrame, JPanel, JDialog) as
  Passive Views, always as a .java + .form pair kept in sync. Use when drawing
  or building Swing screens, generating or hand-editing .form files, wiring the
  NetBeans GUI builder, or making screens openable/regenerable in NetBeans. The
  View builds and configures only its elements (no listeners, no main, getters
  only for the elements the Presenter manipulates, no public setters), follows
  the NetBeans generated-code blocks, and names every element with the Swing
  prefix convention (btn, cmb, lbl, pnl, scr, txt, tbl, menu, etc.). Do NOT use
  for JavaFX, web UI, or non-NetBeans form systems.
license: MIT
metadata:
  ui: swing
  target: netbeans-guibuilder
  pattern: mvp-passive-view
---

# NetBeans-compatible Swing Passive View

Produce a View as TWO files that live side by side and stay in sync:

```
view/
  <Nome>View.java
  <Nome>View.form     <- NetBeans GUI builder metadata (source of the design)
```

The `.form` describes the design; NetBeans regenerates parts of the `.java`
from it. If the `.java` field names and the `.form` `name` attributes diverge,
the form breaks.

## When to use

- Drawing/building a Swing screen to be opened and edited in NetBeans.
- Generating or hand-editing a `.form`.
- Implementing the Passive View side of MVP (see the `mvp-passive-view-java-swing`
  skill for the full architecture).

## When NOT to use

- JavaFX, web UI, or non-NetBeans form systems.

## Passive View rules (never break these)

1. The View ONLY creates/configures its elements. No listeners, no `main`, no
   flow decisions, no Model/service access.
2. Getters exist ONLY for the elements the respective Presenter manipulates.
   No public setters (a setter only if internal and strictly necessary).
3. Listeners are configured in the Presenter, as anonymous classes.
4. The design lives in the `.form`; the `.java` keeps the NetBeans generated
   blocks.

## NetBeans generated-code skeleton

```java
public class <Nome>View extends javax.swing.JFrame implements I<Nome>View {

    public <Nome>View() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        // new javax.swing.J... per component, then properties, layout, adds

        pack();
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public javax.swing.JFrame getJanelaPrincipal() {
        return this;
    }

    // one getter per element the Presenter uses ...

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn<Acao>;
    // ... all fields, same names as the .form
    // End of variables declaration//GEN-END:variables
}
```

## Element naming (prefix convention)

Use these prefixes for fields AND local variables, in the View and Presenter:

| Component | Prefix | Example |
|---|---|---|
| `JButton` | `btn` | `btnSalvar` |
| `JCheckBox` | `chk` | `chkAtivo` |
| `JComboBox` | `cmb` | `cmbCategoria` |
| `JDatePicker` | `dtp` | `dtpDataNascimento` |
| `JDesktopPane` | `dsk` | `dskPrincipal` |
| `JFormattedTextField` | `txtFmt` | `txtFmtCpf` |
| `JLabel` | `lbl` | `lblNome` |
| `JMenu` | `mnu` | `mnuCadastro` |
| `JMenuBar` | `mnb` | `mnbPrincipal` |
| `JMenuItem` | `mit` | `mitSair` |
| `JOptionPane` | `opt` | `optConfirmacao` |
| `JPanel` | `pnl` | `pnlDados` |
| `JPopupMenu` | `pmn` | `pmnOpcoes` |
| `JProgressBar` | `prg` | `prgProgresso` |
| `JRadioButton` | `rad` | `radAdministrador` |
| `JScrollPane` | `scr` | `scrProdutos` |
| `JSplitPane` | `spt` | `sptPrincipal` |
| `JTabbedPane` | `tab` | `tabCadastro` |
| `JTable` | `tbl` | `tblProdutos` |
| `JTextField` | `txt` | `txtNome` |
| `JToggleButton` | `tgl` | `tglAtivo` |
| `JPasswordField` | `txt` | `txtSenha` |

## Workflow

1. Choose the form kind: `JFrameFormInfo`, `JPanelFormInfo` or
   `JDialogFormInfo`.
2. Write `<Nome>View.form` with the components and the naming prefixes.
3. Write `<Nome>View.java` with the same field names and the generated blocks.
4. Implement `I<Nome>View` (getters + `getJanelaPrincipal()` for a JFrame).
5. Open in NetBeans to confirm the form loads and regenerates.

## References

- `references/form-format.md` - full `.form` XML format and mappings.
- `references/swing-element-prefixes.md` - the prefix table.
- `references/passive-view-rules.md` - the Passive View rules.

## Templates

- `assets/View.java.template`
- `assets/JFrame.form.template`
- `assets/JPanel.form.template`

## Authoring note

Each Java file may carry the NetBeans author comment before the type:

```java
/**
 *
 * @author <autor>
 */
```
