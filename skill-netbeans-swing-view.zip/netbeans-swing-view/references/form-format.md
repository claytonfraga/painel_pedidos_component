# The NetBeans `.form` format

A `.form` is the design metadata for a Swing class. NetBeans reads it to render
the GUI builder and to regenerate parts of the `.java`. It must sit next to the
`.java` with the same base name (`<Nome>View.java` + `<Nome>View.form`).

## Root element

```xml
<?xml version="1.0" encoding="UTF-8" ?>

<Form version="1.3" maxVersion="1.9" type="org.netbeans.modules.form.forminfo.JFrameFormInfo">
  ...
</Form>
```

Form types by component:

| Class base | `type` |
|---|---|
| `JFrame` | `org.netbeans.modules.form.forminfo.JFrameFormInfo` |
| `JPanel` | `org.netbeans.modules.form.forminfo.JPanelFormInfo` |
| `JDialog` | `org.netbeans.modules.form.forminfo.JDialogFormInfo` |

## Top-level sections

```xml
<Properties>            <!-- form/root properties -->
  <Property name="defaultCloseOperation" type="int" value="2"/>
  <Property name="title" type="java.lang.String" value="Titulo"/>
</Properties>
<SyntheticProperties>   <!-- builder-generated, not real properties -->
  <SyntheticProperty name="formSizePolicy" type="int" value="1"/>
  <SyntheticProperty name="generateCenter" type="boolean" value="false"/>
</SyntheticProperties>
<AuxValues>             <!-- builder settings; copy verbatim -->
  <AuxValue name="FormSettings_autoResourcing" type="java.lang.Integer" value="0"/>
  <AuxValue name="FormSettings_autoSetComponentName" type="java.lang.Boolean" value="false"/>
  <AuxValue name="FormSettings_generateFQN" type="java.lang.Boolean" value="true"/>
  <AuxValue name="FormSettings_generateMnemonicsCode" type="java.lang.Boolean" value="false"/>
  <AuxValue name="FormSettings_i18nAutoMode" type="java.lang.Boolean" value="false"/>
  <AuxValue name="FormSettings_layoutCodeTarget" type="java.lang.Integer" value="1"/>
  <AuxValue name="FormSettings_listenerGenerationStyle" type="java.lang.Integer" value="3"/>
  <AuxValue name="FormSettings_variablesLocal" type="java.lang.Boolean" value="false"/>
  <AuxValue name="FormSettings_variablesModifier" type="java.lang.Integer" value="2"/>
  <!-- designerSize is optional; NetBeans regenerates it -->
  <AuxValue name="designerSize" type="java.awt.Dimension"
             value="-84,-19,0,5,115,114,0,18,106,97,118,97,46,97,119,116,46,68,105,109,101,110,115,105,111,110,65,-114,-39,-41,-84,95,68,20,2,0,2,73,0,6,104,101,105,103,104,116,73,0,5,119,105,100,116,104,120,112,0,0,1,44,0,0,1,-112"/>
</AuxValues>
```

- `variablesModifier` value `2` = `private` (default for fields).
- `listenerGenerationStyle` value `3` = a common generator style.

## Layout

```xml
<Layout class="org.netbeans.modules.form.compat2.layouts.DesignBorderLayout">
  <Property name="horizontalGap" type="int" value="8"/>
  <Property name="verticalGap" type="int" value="8"/>
</Layout>
```

Common layout classes:

| NetBeans layout | Java |
|---|---|
| `DesignBorderLayout` | `BorderLayout` |
| `DesignFlowLayout` | `FlowLayout` |
| `DesignGridLayout` | `GridLayout` |
| `DesignGridBagLayout` | `GridBagLayout` |
| `org.netbeans.modules.form.compat2.layouts.support.JScrollPaneSupportLayout` | JScrollPane viewport |

## Subcomponents

`<SubComponents>` holds `<Component>` (leaf, e.g. JLabel/JTextField/JButton) and
`<Container>` (a component that itself has `<SubComponents>`).

```xml
<SubComponents>
  <Component class="javax.swing.JLabel" name="lblNome">
    <Properties>
      <Property name="text" type="java.lang.String" value="Nome:"/>
    </Properties>
  </Component>

  <Container class="javax.swing.JPanel" name="pnlDados">
    <Constraints>
      <Constraint layoutClass="org.netbeans.modules.form.compat2.layouts.DesignBorderLayout"
                  value="org.netbeans.modules.form.compat2.layouts.DesignBorderLayout$BorderConstraintsDescription">
        <BorderConstraints direction="Center"/>
      </Constraint>
    </Constraints>
    <Layout class="org.netbeans.modules.form.compat2.layouts.DesignFlowLayout"/>
    <SubComponents>
      <Component class="javax.swing.JTextField" name="txtNome">
        <Properties>
          <Property name="columns" type="int" value="20"/>
        </Properties>
      </Component>
      <Component class="javax.swing.JButton" name="btnSalvar">
        <Properties>
          <Property name="text" type="java.lang.String" value="Salvar"/>
        </Properties>
      </Component>
    </SubComponents>
  </Container>
</SubComponents>
```

The `name` attribute is the Java field name. Keep it identical to the field in
the `//GEN-BEGIN:variables` block.

### BorderLayout constraints

Inside a `DesignBorderLayout`, a child carries:

```xml
<Constraints>
  <Constraint layoutClass="...DesignBorderLayout" value="...DesignBorderLayout$BorderConstraintsDescription">
    <BorderConstraints direction="North"/>   <!-- North|South|East|West|Center -->
  </Constraint>
</Constraints>
```

(Skip `<Constraints>` for the single/only child when the layout does not need
it, e.g. FlowLayout children.)

### Dimension properties

```xml
<Property name="preferredSize" type="java.awt.Dimension"
          editor="org.netbeans.beaninfo.editors.DimensionEditor">
  <Dimension value="[150, 30]"/>
</Property>
```

### JComboBox type parameter

```xml
<Component class="javax.swing.JComboBox" name="cmbCategoria">
  <AuxValues>
    <AuxValue name="JavaCodeGenerator_TypeParameters" type="java.lang.String" value="&lt;String&gt;"/>
  </AuxValues>
</Component>
```

## XML escaping

Escape non-ASCII text (accented labels) with XML character references:

| Character | Reference |
|---|---|
| `í` | `&#xed;` |
| `ç` | `&#xe7;` |
| `ã` | `&#xe3;` |
| `õ` | `&#xf5;` |
| `ó` | `&#xf3;` |
| `é` | `&#xe9;` |

## Sync rules

- `.java` and `.form` share the base name and the folder.
- Each `name` attribute has a matching private field (same name).
- Do not rename a field in `.java` without renaming it in the `.form`.
- Open the form in NetBeans to validate; it should load and regenerate.

## Cores: SEMPRE em hexadecimal

O `ColorEditor` do NetBeans le os atributos `red`/`green`/`blue` como **hex**.
Valor decimal e lido como hex e estoura a faixa: `red="247"` = 0x247 = 583,
que produz

```
java.lang.IllegalArgumentException: Color parameter outside of expected range: Red Green Blue
    at org.netbeans.beaninfo.editors.ColorEditor.readFromXML(ColorEditor.java:910)
```

```xml
<!-- ERRADO: 247, 239, 232 -->
<Color blue="247" green="239" red="232" type="rgb"/>
<!-- CERTO: e8, ef, f7 -->
<Color blue="f7" green="ef" red="e8" type="rgb"/>
```

## Bordas com titulo

`TitledBorder`, `EmptyBorder` e `LineBorder` sao validos no `<BorderInfo>`. O
`<Color>` dentro da borda segue a mesma regra hexadecimal acima - e quando a cor
esta errada o erro aparece no `BorderEditor`, nao no `ColorEditor`:

```
org.openide.ErrorManager$AnnException: msg
    at org.netbeans.modules.form.editors2.BorderEditor.readFromXML(BorderEditor.java:555)
```

Leia sempre a causa raiz ao final do stack trace: um erro de borda costuma ser
cor em decimal.

```xml
<Property name="border" type="javax.swing.border.Border" editor="org.netbeans.modules.form.editors2.BorderEditor">
  <BorderInfo>
    <TitledBorder title="Filtros"/>
    <EmptyBorder bottom="0" left="0" right="0" top="0"/>
  </BorderInfo>
</Property>
```

## Bordas: prefira em CODIGO, fora dos blocos gerados

O `<BorderInfo>` e o ponto mais fragil do form. Ele **pode** ser valido, mas ja
falhou duas vezes seguidas aqui, sempre com o mesmo sintoma:

```
org.openide.ErrorManager$AnnException: msg
    at org.netbeans.modules.form.editors2.BorderEditor.readFromXML(BorderEditor.java:555)
```

Duas licoes praticas:

1. `AnnException: msg` e uma **anotacao** do NetBeans, nao o erro. A causa esta
   *depois* dela (`Caused by:` ou a ultima excecao solta). Ao reportar, mande a
   **cauda** do stack, nao o topo - sem ela ninguem corrige.
2. O caminho robusto e **tirar as bordas do form** e configura-las em codigo, num
   metodo chamado pelo construtor **depois** de `initComponents()`. O form fica
   so com o que e documentado (layout, constraints, `Dimension`, fonte, texto,
   `opaque` e cor em hex), o NetBeans carrega, e `configurarBordas()` e
   preservado porque esta fora dos blocos gerados.

```java
public <Nome>View() {
    initComponents();
    configurarBordas();
}

private void configurarBordas() {
    pnlFiltros.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtros"));
    scrNovo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(225, 230, 235)));
}
```

O custo: as bordas deixam de ser editaveis no designer (o resto continua). Troca
justa por um form que abre.

## JSpinner: o modelo NAO vai no form

`org.netbeans.modules.form.editors.SpinnerModelEditor` **nao existe** - declara-la
quebra o carregamento do form com

```
java.lang.ClassNotFoundException: org.netbeans.modules.form.editors.SpinnerModelEditor
```

O `JSpinner` entra no form apenas como componente (o `initComponents` gera
`new JSpinner()`), e o modelo/editor sao configurados **fora** dos blocos
gerados, num metodo chamado pelo construtor depois de `initComponents()`:

```java
public <Nome>View() {
    initComponents();
    configurarSpinnerDeData();
}

private void configurarSpinnerDeData() {
    spnData.setModel(new javax.swing.SpinnerDateModel());
    spnData.setEditor(new JSpinner.DateEditor(spnData, "dd/MM/yyyy"));
}
```

## Conferencia antes de abrir no NetBeans

Sem NetBeans, de para conferir a regra de sincronizacao comparando os nomes:

```bash
grep -oP '<(Component|Container) class="[^"]+" name="\K\w+' <View>.form | sort -u > /tmp/form.txt
sed -n '/GEN-BEGIN:variables/,/GEN-END:variables/p' <View>.java \
  | grep -oP 'private \S+ \K\w+' | sort > /tmp/campos.txt
comm -13 /tmp/campos.txt /tmp/form.txt   # no form sem campo
comm -23 /tmp/campos.txt /tmp/form.txt   # campo sem componente no form
```

Os dois vazios significam que o form referencia exatamente os campos da View.
