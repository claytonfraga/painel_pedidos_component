# Passive View rules (View side)

The View is deliberately passive.

## Must

- Build and configure only its elements (in `initComponents()`).
- Expose getters only for the elements the respective Presenter manipulates.
- Provide `getJanelaPrincipal()` (JFrame/JDialog) for window/dialog operations.
- Keep the `.form` and the `.java` in sync.
- Use the element prefix convention.

## Must NOT

- Configure listeners (the Presenter does).
- Have a `main` method.
- Contain flow decisions, validation, or Model/service access.
- Expose public setters (a setter only if internal and strictly necessary).

## Notes

- Maximize by default with `setExtendedState(MAXIMIZED_BOTH)` after `pack()`.
- Do not print stack traces; let the Presenter surface errors.
- If a configuration helper is needed, keep it `private` and free of listeners;
  prefer inlining properties into `initComponents()` as NetBeans does.
- The View implements `I<Nome>View` so the Presenter depends on the abstraction.
